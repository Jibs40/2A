#ifndef LIVRE_H
#define LIVRE_H

#include "Media.hpp"

enum class Collection : int{roman, manga, biographie, autre};

class Livre: public Media {
      public:

            Livre(std::string auteur, std::string titre, int anneePublication, int nbPage, enum Collection collection, std::string resume, int &idElement);

            void afficheInfo(void);
            bool sauvegarde(std::ofstream &outfile);
            bool rechercheChaine(std::string data);
            std::string retourneCollection(enum Collection _collection);

      protected:
            int _anneePublication;
            int _nbPage;
            enum Collection _collection;
            std::string _resume;
      private : 
            std::string _type;
};

#endif