#ifndef AJOUTDONNEES_h
#define AJOUTDONNEES_h

#include "Mediatheque.hpp"

class AjoutDonnees{
    public : 
        static void ajoutDonnees(std::string chaine);
        static bool chargeFichier(const std::string &nomFichier);

    private :
};
#endif