#ifndef RESSOURCENUMERIQUE_H
#define RESSOURCENUMERIQUE_H

#include "Media.hpp"

enum class Type : int {PDF,DOC,PPT,Autre};

class RessourceNumerique : public Media{
    public:

    RessourceNumerique(std::string auteur, std::string titre,const enum Type type_support,
        const int taille_Mo,
        const std::string nom,
        const std::string chemin_URL,
        int &idElement);

        void afficheInfo(void);
        bool sauvegarde(std::ofstream &outfile);
        bool rechercheChaine(std::string data);
        std::string retourneType(enum Type _type);

    protected:
        std::string _nom;
        std::string _chemin_URL;
        Type _type_support;
        int _taille_Mo;

    private : 
        std::string _type;


};

#endif