#ifndef MEDIATHEQUE_H
#define MEDIATHEQUE_H

#include <map>

#include "RessourceNumerique.hpp"
#include "Vhs.hpp"
#include "Cd.hpp"
#include "Revue.hpp"
#include "Media.hpp"
#include "AjoutDonnees.hpp"
#include <fstream>
#include <string>


class Mediatheque{
    public : 
        Mediatheque(void);
        void saisieUtilisateur(void);
        void supprimeRessource(int id);
        void stockeElement(Media *media, int nbElements);     
        bool sauvegardeDonnees(std::string);
        bool rechercheDonnees(std::string);
        void afficheInfos(void);
        void afficheInfos(int id);
        void reset(void);


    private:

};

#endif