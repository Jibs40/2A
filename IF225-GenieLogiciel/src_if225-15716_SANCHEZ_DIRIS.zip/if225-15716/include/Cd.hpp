#ifndef CD_H
#define CD_H

#include "Media.hpp"
#include "Dvd.hpp"

class Cd : public Dvd{

    public:
        Cd(int nbPiste,std::string maisonProd, int duree, std::string auteur, std::string titre, int &idElement);

        void afficheInfo(void);
        bool sauvegarde(std::ofstream &outfile);
        bool rechercheChaine(std::string data);

    private:
        std::string _type;
};

#endif