#ifndef MEDIA_H
#define MEDIA_H

#include <string>
#include <fstream>
#include <iostream>

class Media {
    public:

        Media(const std::string auteur, const std::string titre, int idElement);

        virtual void afficheInfo(void) = 0 ;
        virtual bool sauvegarde(std::ofstream &outfile) = 0;
        virtual bool rechercheChaine(std::string data) = 0;

    protected : 
        std::string _auteur;
        std::string _titre;
        int _idElement;
};

#endif
