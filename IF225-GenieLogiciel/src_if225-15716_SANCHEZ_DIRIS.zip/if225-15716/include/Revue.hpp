#ifndef REVUE_H
#define REVUE_H

#include "Media.hpp"
#include "Livre.hpp"

class Revue: public Livre {

    public:
        Revue(std::string auteur,
        std::string titre,
        int anneePublication,
        int nbPage, 
        enum Collection collection,
        std::string resume,
        std::string editeur, 
        int nbArticle, 
        std::string nomArticle,
        int &idElement);

        void afficheInfo(void);
        bool sauvegarde(std::ofstream &outfile);
        bool rechercheChaine(std::string data);

    protected:
        std::string _editeur;
        int _nbArticle;
        std::string _nomArticle;

    private : 
        std::string _type;

};

#endif