#ifndef VHS_H
#define VHS_H

#include "Media.hpp"

class Vhs : public Media{
    public : 
        Vhs(std::string maisonProd, int duree, std::string auteur, std::string titre, int &idElement);

        void afficheInfo(void);
        bool sauvegarde(std::ofstream &outfile);
        bool rechercheChaine(std::string data);


    protected : 
        std::string _maisonProd;
        int _duree;
        
    private :         
        std::string _type;

};
#endif