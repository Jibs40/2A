#ifndef DVD_H
#define DVD_H

#include "Vhs.hpp"
#include "Media.hpp"

class Dvd: public Vhs {

    public:
        Dvd(int nbPiste,std::string maisonProd,int duree,std::string auteur,std::string titre,int &idElement);

        void afficheInfo(void);
        bool sauvegarde(std::ofstream&outfile);
        bool rechercheChaine(std::string data);

    protected:
        int _nbPiste;

    private:
        std::string _type;
};

#endif