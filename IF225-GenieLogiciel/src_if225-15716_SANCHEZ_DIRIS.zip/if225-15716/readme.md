# IF225-Projet Médiatheque
***
Ce projet s’intéresse au développement d’une application permettant de gérer une médiathèque en C++
L’application permet de gérer la disponibilité de l’ensemble les ressources disponibles dans la médiathèque : des livres, des CD, des DVD, des revues, des vidéos VHS et des ressources numériques.
Les informations mémorisées pour chacune des ressources contenues dans la médiathèque sont dépendantes du type de la ressource.
***
## Informations générales
***
### Organisation des répertoires
***
1/ build est un dossier comprenant uniquement un fichier test "datas.txt". 
Ce dossier servira pour la compilation .
2/ include regroupe l'ensemble des headers.
3/ src regroupe l'ensemble des sources.
***
### Générations des exécutables
***
Ce dossier est accompagné d'un fichier "CMakeLists.txt" et d'un dossier "build" vide.
La génération des exécutables s'effectue en 2 parties:
1/ Rendez-vous dans le dossier "build" et exécutez la commande : "cmake ..", une fois cette étape exécutée, vous avez généré le makefile.
2/ Toujours dans le même dossier, tapez la commande "make".
***
L'exécutable "Mediatheque" est alors généré.
Pour lancer l'interface, tapez "./Mediatheque" dans votre terminal.
***
### Screenshot
***
L'interface d'entrée de la médiatheque peut être retrouvée ci-dessous:
Pour pouvoir naviguer dans la médiathèque, il suffit d'entrer les commandes proposées, accompagnées des arguments si nécessaire.
![Interface Mediatheque]</captureEcran/interfaceMediatheque.png>
### Fichiers de tests
***
Dans le dossier "build" est présent un fichier "datas.txt" pour test.
Ce fichier contient plusieurs ressources (toutes les ressources sont testées) pour ajouter au contenu de la médiathèque.
Pour les ajouter il suffira de taper la commande "LOAD datas.txt" dans la médiathèque.
Attention, ceci effacera toutes les données précédemment contenues dans la médiathèque.
