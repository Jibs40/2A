#include "AjoutDonnees.hpp"


#include <algorithm>
#include <string>
using namespace std;

using std::cout; using std::string;
using std::endl; using std::cin;
using std::transform; using std::toupper;

static int idElement= 0;

// Variables qui peuvent servir à tous
std::string auteur;
std::string titre;
int anneePublication;
int nbPage;
int collection;
int intCollec;
std::string resume;

// Variables spécifiques à VHS, DVD
string MaisonProd;
int duree;

// Variables spécifiques à DVD
int nbPiste;

// Variables spécifiques à Revue
string editeur;
int nbArticle;
string nomArticle;

// Variables spécifiques à Ressource numérique
int type_support;
int taille_Mo;
string nom;
string chemin_URL;

Mediatheque maMediatheque;

int getCollection(string format){
    if (!format.find( "Roman" ))
        return 0;
    else if (!format.find( "Manga" ))
        return 1;
    else if (!format.find( "Biographie" ))
        return 2;
    else    
        return 3;
}

int getType(string format){
    if (!format.find( "PDF" ))
        return 0;
    else if (!format.find( "DOC" ))
        return 1;
    else if (!format.find( "PPT" ))
        return 2;
    else    
        return 3;
}

void AjoutDonnees::ajoutDonnees(std::string chaine){

if (!(chaine).find("ADD VHS")){
        string buffer_vhs;
        cout <<"Ajout d'une VHS"<<endl;

        cout <<"Auteur?"<<endl;
        getline(cin,auteur);

        cout <<"Titre?"<<endl;
        getline(cin,titre);

        cout <<"Maison de Production ?"<<endl;
        getline(cin,MaisonProd);

        cout <<"Durée ?"<<endl;
        getline(cin,buffer_vhs);
        
        try
        {
        duree = stoi(buffer_vhs);        
        }
        catch(const invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }
        
    
        Vhs *vhs = new Vhs(MaisonProd, duree, auteur,titre,idElement);
        maMediatheque.stockeElement(vhs,idElement);
        idElement++;
        cout << "VHS stockée!"<<endl;

        }
        else if (!chaine.find("ADD DVD")){
        string buffer_dvd;
        cout <<"Ajout d'un DVD"<<endl;

        cout <<"Auteur?"<<endl;
        getline(cin,auteur);

        cout <<"Titre?"<<endl;
        getline(cin,titre);

        cout <<"Maison de Production ?"<<endl;
        getline(cin,MaisonProd);

        cout <<"Durée ?"<<endl;
        getline(cin,buffer_dvd);
        
        try
        {
        duree = stoi(buffer_dvd);
        }
        catch(const invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }


        cout <<"Nombre de piste ?"<<endl;
        getline(cin,buffer_dvd);

        try
        {
            nbPiste = stoi(buffer_dvd);
        }
        catch(const invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }



        Dvd *dvd = new Dvd(nbPiste, MaisonProd, duree, auteur,titre, idElement);
        maMediatheque.stockeElement(dvd,idElement);
        idElement++;
        cout << "DVD stocké!"<<endl;

        }
        else if (!chaine.find("ADD CD")){
        string buffer_cd;
        cout <<"Ajout d'un CD"<<endl;
       
        cout <<"Auteur?"<<endl;
        getline(cin,auteur);

        cout <<"Titre?"<<endl;
        getline(cin,titre);

        cout <<"Maison de Production ?"<<endl;
        getline(cin,MaisonProd);

        cout <<"Durée ?"<<endl;
        getline(cin,buffer_cd);

        try
        {
        duree = stoi(buffer_cd);
        }
        catch(const invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }        

        cout <<"Nombre de piste ?"<<endl;
        getline(cin,buffer_cd);

        try
        {
            nbPiste = stoi(buffer_cd);
        }
        catch(const invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }     


        Cd *cd = new Cd(nbPiste, MaisonProd, duree, auteur,titre, idElement);
        maMediatheque.stockeElement(cd,idElement);
        idElement++;
        cout << "CD stocké!"<<endl;
        }
        
        else if (!chaine.find("ADD LIVRE")){
        string buffer;

        cout <<"Ajout d'un LIVRE"<<endl;

        cout <<"Auteur?"<<endl;
        getline(cin,auteur);

        cout <<"Titre?"<<endl;
        getline(cin,titre);

        cout <<"Annee Publication?"<<endl;
        getline(cin,buffer);


        try
        {
            anneePublication = stoi(buffer);
        }
        catch(const std::invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }

        cout <<"Nombre de pages?"<<endl;
        getline(cin,buffer);

        try
        {
        nbPage = stoi(buffer);
        }
        catch(const std::invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }

        cout <<"Collection?"<<"(Choix possibles : Roman, Manga, Biographie, Autre)"<<endl;
        getline(cin,buffer);
        
        intCollec= getCollection(buffer);

        cout <<"Resume?"<<endl;
        getline(cin,resume);

        Livre *livre = new Livre(auteur,titre,anneePublication,nbPage,Collection(intCollec),resume,idElement);
        maMediatheque.stockeElement(livre, idElement);
        idElement++;
        cout << "Livre stocké!"<<endl;
        }

        else if (!chaine.find("ADD REVUE")){
        string buffer_revue;
        cout <<"Ajout d'une REVUE"<<endl;
         
        cout <<"Auteur?"<<endl;
        getline(cin,auteur);

        cout <<"Titre?"<<endl;
        getline(cin,titre);

        cout <<"Annee Publication?"<<endl;
        getline(cin,buffer_revue);
        
        try
        {
           anneePublication = stoi(buffer_revue);
        }
        catch(const std::invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }

        cout <<"Nombre de pages?"<<endl;
        getline(cin,buffer_revue);

        try
        {
            nbPage = stoi(buffer_revue);
        }
        catch(const std::invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }
        


        cout <<"Collection?"<<"(Choix possibles : roman, manga, biographie, autre)"<<endl;
        getline(cin,buffer_revue);
        collection = getCollection(buffer_revue);

        cout <<"Resume?"<<endl;
        getline(cin,resume);

        cout <<"Editeur?"<<endl;
        getline(cin,editeur);

        cout <<"Nombre d'articles?"<<endl;
        getline(cin,buffer_revue);
        
        try
        {
            nbArticle = stoi(buffer_revue);
        }
        catch(const std::invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }

        cout <<"Nom d'article?"<<endl;
        getline(cin,nomArticle);

        Revue *revue = new Revue(auteur,titre,anneePublication,nbPage,Collection(collection),resume, editeur, nbArticle, nomArticle, idElement);
        maMediatheque.stockeElement(revue,idElement);
        idElement++;
        cout << "Revue stockée!"<<endl;
        }

        else if (!chaine.find("ADD RESSOURCE NUMERIQUE")){
        string buffer_ressnum;
        cout <<"Ajout d'une RESSOURCE NUMERIQUE"<<endl;

        cout <<"Auteur?"<<endl;
        getline(cin,auteur);

        cout <<"Titre?"<<endl;
        getline(cin,titre);

        cout <<"Type support? "<<"(Choix possibles : PDF, DOC, PPT, Autre)"<<endl;

        getline(cin,buffer_ressnum);
        type_support = getType(buffer_ressnum);

        cout <<"Taille en Mo?"<<endl;
        getline(cin,buffer_ressnum);
        try
        {
            taille_Mo = stoi(buffer_ressnum);
        }
        catch(const std::invalid_argument)
        {
            cout << "Saisie invalide, ce paramètre vaudra 0"<< endl;
        }        

        cout <<"Nom?"<<endl;
        getline(cin,nom);

        cout <<"Chemin URL?"<<endl;
        getline(cin,chemin_URL);


        RessourceNumerique *ressourceNumerique = new RessourceNumerique(auteur, titre, Type(type_support), taille_Mo, nom, chemin_URL, idElement);
        maMediatheque.stockeElement(ressourceNumerique,idElement);
        idElement++;
        cout << "Ressource numérique stockée!"<<endl;

        }

        else{
            cout << "Je n'ai pas compris votre demande"<<endl;
        }
}
        
std::string litFichier(ifstream &file){
    string bufferDatas;
    if(file.eof())
        return "";
    getline(file, bufferDatas);
    return bufferDatas;
}

bool AjoutDonnees::chargeFichier(const string &nomFichier){
string buffer;
ifstream infile;

    infile.open(nomFichier, std::ifstream::in); 
    if (infile.fail()){
        cout << "Erreur d'ouverture de base de donnée" << endl;
        return -1;
    }

maMediatheque.reset(); 


while(!infile.eof()){    
    getline(infile,buffer);
    
    if (!buffer.compare( "Livre" )){   
        auteur = litFichier(infile);
        titre= litFichier(infile);
        anneePublication = stoi(litFichier(infile));
        nbPage = stoi(litFichier(infile));
        collection = getCollection(litFichier(infile));
        resume = litFichier(infile);
        Livre *livre = new Livre(auteur,titre,anneePublication,nbPage,Collection(collection),resume,idElement);
        maMediatheque.stockeElement(livre,idElement); 
        idElement++;
        cout << "Livre stocké" << endl;
    }
    else if(!buffer.compare( "Cd" )){    
        nbPiste = stoi(litFichier(infile));
        MaisonProd = litFichier(infile);
        duree = stoi(litFichier(infile));
        auteur= litFichier(infile);
        titre= litFichier(infile);        
        Cd *cd = new Cd(nbPiste,MaisonProd,duree,auteur,titre,idElement);
        maMediatheque.stockeElement(cd,idElement);
        idElement++;
        cout << "CD stocké" << endl;
        }  

    else if(!buffer.compare( "Dvd" )){   
        nbPiste = stoi(litFichier(infile));
        MaisonProd = litFichier(infile);
        duree = stoi(litFichier(infile));
        auteur= litFichier(infile);
        titre= litFichier(infile);
        Dvd *dvd = new Dvd(nbPiste,MaisonProd,duree,auteur,titre,idElement);
        maMediatheque.stockeElement(dvd,idElement); 
        idElement++;
        cout << "DVD stocké" << endl;
        }        

    else if(!buffer.compare( "Vhs" )){   
        MaisonProd = litFichier(infile);
        duree = stoi(litFichier(infile));
        auteur= litFichier(infile);
        titre= litFichier(infile);
        Vhs *vhs = new Vhs(MaisonProd,duree,auteur,titre,idElement);
        maMediatheque.stockeElement(vhs, idElement); 
        idElement++;
        cout << "VHS stockée" << endl;
        }

    else if(!buffer.compare( "Revue" )){   
        auteur = litFichier(infile);
        titre= litFichier(infile);
        anneePublication = stoi(litFichier(infile));
        nbPage = stoi(litFichier(infile));
        collection = getCollection(litFichier(infile));
        resume = litFichier(infile);
        editeur = litFichier(infile);
        nbArticle = stoi(litFichier(infile));
        nomArticle = litFichier(infile); 
        Revue *revue = new Revue(auteur,titre,anneePublication,nbPage,Collection(collection),resume,editeur,nbArticle,nomArticle,idElement);
        
        
        maMediatheque.stockeElement(revue,idElement); 
        idElement++;     
        cout << "Revue stockée" << endl;
        }

    else if(!buffer.compare( "Ressource Numerique" )){  
        auteur = litFichier(infile);
        titre= litFichier(infile);  
        type_support= getType(litFichier(infile));
        taille_Mo= stoi(litFichier(infile));
        nom = litFichier(infile);
        chemin_URL = litFichier(infile);
        
        RessourceNumerique *ressourceNumerique = new RessourceNumerique(auteur,titre,Type(type_support),taille_Mo,nom,chemin_URL,idElement);      
        maMediatheque.stockeElement(ressourceNumerique,idElement); 
        idElement++;
        cout << "Ressource Numérique stockée" << endl;
        }
}
return 0;
}

