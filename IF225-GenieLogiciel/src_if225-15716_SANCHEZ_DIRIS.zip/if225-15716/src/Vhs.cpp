#include "Mediatheque.hpp"

using namespace std;

Vhs::Vhs(std::string MaisonProd, int duree, std::string auteur, std::string titre, int &idElement):
    Media(auteur,titre, idElement),
    _duree(duree),
    _maisonProd(MaisonProd),
    _type("Vhs")

    { }

void Vhs::afficheInfo(void){
    cout << "Type : " <<_type<< "\t";
    cout << "ID Element : " <<_idElement<< "\t";
    cout << "Titre : " <<_titre << "\t";
    cout << "Auteur : " << _auteur << "\t";
    cout << "Maison de Production : " << _maisonProd << "\t";
    cout << "Durée : " <<_duree << endl;
}


bool Vhs::sauvegarde(ofstream &outfile){
    outfile << _type << endl;
    outfile << _maisonProd << endl;
    outfile << _duree << endl;
    outfile << _auteur << endl;
    outfile << _titre << endl;

    return 0;
}

bool Vhs::rechercheChaine(string data){
    if(!data.find(_auteur)) 
        return 0;
    else if (!data.find(_type)) 
        return 0;
    else if (!data.find(_titre)) 
        return 0;
    else if (!data.find(_maisonProd)) 
        return 0; 
    else if (!data.find(to_string(_duree))) 
        return 0;       
    else if (!data.find(to_string(_idElement))) 
        return 0; 
    else 
        return 1;
}