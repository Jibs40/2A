#include "Media.hpp"
#include "Mediatheque.hpp"


using namespace std;

    Media :: Media(const std::string auteur, const std::string titre, int idElement) :

    _auteur(auteur),
    _titre(titre),
    _idElement(idElement)
    {}  
