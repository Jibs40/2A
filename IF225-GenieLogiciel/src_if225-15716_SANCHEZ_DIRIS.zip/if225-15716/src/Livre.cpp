#include "Mediatheque.hpp"

using namespace std;

Livre::Livre(std::string auteur, std::string titre, int anneePublication, int nbPage, enum Collection collection, std::string resume, int &idElement):
    
    Media(auteur,titre,idElement),
    _anneePublication(anneePublication),
    _nbPage(nbPage),
    _collection(collection),
    _resume(resume),
    _type("Livre")

{}

void Livre::afficheInfo(void){
    cout << "Type : " <<_type
        << "\t" << "Id Element : " <<_idElement 
        << "\t" << "Titre : " << _titre 
        << "\t" << "Auteur : "<<_auteur 
        << "\t" << "Annee Publication : "<<_anneePublication 
        << "\t" << "Nombre pages : "<< _nbPage  
        << "\t" << "Collection : " << retourneCollection(_collection)
        << "\t" <<"Résumé : "<< _resume << endl;
}

bool Livre::sauvegarde(ofstream &outfile){
    outfile << _type << endl;
    outfile << _auteur << endl;
    outfile << _titre << endl;
    outfile << _anneePublication << endl;
    outfile << _nbPage << endl;
    outfile << retourneCollection(_collection) << endl;
    outfile << _resume  << endl;

    return 0;
}

bool Livre::rechercheChaine(string data){
    if(!data.find(_auteur)) 
        return 0;
    else if (!data.find(_type)) 
        return 0;
    else if (!data.find(_titre)) 
        return 0;
    else if (!data.find(_resume)) 
        return 0; 
    else if (!data.find(retourneCollection(_collection))) 
        return 0;   
    else if (!data.find(to_string(_anneePublication))) 
        return 0; 
    else if (!data.find(to_string(_nbPage))) 
        return 0;     
    else if (!data.find(to_string(_idElement))) 
        return 0;     
    else 
        return 1;
}

string Livre::retourneCollection(enum Collection _collection){
    if (_collection == Collection::roman)
        return "Roman";
    else if (_collection == Collection::manga)
        return "Manga";
    else if (_collection == Collection::biographie)
        return "Biographie";
    else    
        return "Autres";
}

