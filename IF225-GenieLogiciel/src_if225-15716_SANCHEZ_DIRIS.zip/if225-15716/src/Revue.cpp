#include "Mediatheque.hpp"

using namespace std;

Revue::Revue(string auteur,
            string titre,
            int anneePublication,
            int nbPage, 
            enum Collection collection,
            string resume,
            string editeur, 
            int nbArticle, 
            string nomArticle,
            int &idElement):

    Livre(auteur,
        titre,
        anneePublication,
        nbPage,
        collection,
        resume,
        idElement),

    _editeur(editeur),
    _nbArticle(nbArticle),
    _nomArticle(nomArticle),
    _type("Revue")
{}


void Revue::afficheInfo(void){
        cout << "Type : " <<_type << "\t";
        cout << "ID Element : " <<_idElement << "\t";
        cout << "Titre : " <<_titre << "\t";
        cout << "Auteur : " << _auteur << "\t";
        cout << "Année publication : " <<_anneePublication << "\t";
        cout << "Nombre de pages : " << _nbPage << "\t";
        cout << "Collection : " << retourneCollection(_collection) << "\t";
        cout << "Résumé : " <<_resume << "\t";
        cout << "Nombre article : " <<_nbArticle << "\t";
        cout << "Nom article : " <<_nomArticle << endl;
}

bool Revue::sauvegarde(ofstream &outfile){

    outfile << _type << endl;
    outfile << _auteur << endl;
    outfile << _titre << endl;
    outfile << _anneePublication << endl;
    outfile << _nbPage << endl;
    outfile << retourneCollection(_collection) << endl;
    outfile << _resume << endl;
    outfile << _editeur << endl;
    outfile << _nbArticle << endl;
    outfile << _nomArticle << endl;

    return 0;
}

bool Revue::rechercheChaine(string data){
    if(!data.find(_auteur)) 
        return 0;
    else if (!data.find(_type)) 
        return 0;
    else if (!data.find(_titre)) 
        return 0;
    else if (!data.find(_resume)) 
        return 0; 
    else if (!data.find(_editeur)) 
        return 0;   
    else if (!data.find(_nomArticle)) 
        return 0;                
    else if (!data.find(retourneCollection(_collection))) 
        return 0;   
    else if (!data.find(to_string(_anneePublication))) 
        return 0; 
    else if (!data.find(to_string(_nbPage))) 
        return 0;     
    else if (!data.find(to_string(_idElement))) 
        return 0;     
    else 
        return 1;
}