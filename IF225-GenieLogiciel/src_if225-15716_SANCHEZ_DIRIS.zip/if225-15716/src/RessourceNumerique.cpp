#include "Mediatheque.hpp"

using namespace std;

RessourceNumerique :: RessourceNumerique(std::string auteur, std::string titre, const enum Type type_support,
    const int taille_Mo,
    const std::string nom,
    const std::string chemin_URL,
    int &idElement) :

    Media(auteur,titre,idElement),

    _type_support(type_support),
    _taille_Mo(taille_Mo),
    _nom(nom),
    _chemin_URL(chemin_URL),
    _type("Ressource Numerique")

    {}

void RessourceNumerique::afficheInfo(void){
        cout << "Type : " << _type << "\t";
        cout << "ID Element : " << _idElement << "\t";
        cout << "Type de support : " << retourneType(_type_support) << "\t";
        cout << "Taille en Mo : " <<_taille_Mo << "\t";
        cout << "Nom : " << _nom << "\t";
        cout << "Chemin URL : " << _chemin_URL << endl;
}

bool RessourceNumerique::sauvegarde(ofstream &outfile){

    outfile << _type << endl;
    outfile << _auteur << endl;
    outfile << _titre << endl;
    outfile << retourneType(_type_support)  << endl;
    outfile << _taille_Mo << endl;
    outfile << _nom << endl;
    outfile << _chemin_URL << endl;

    return 0;
}

bool RessourceNumerique::rechercheChaine(string data){
    if(!data.find(_auteur)) 
        return 0;
    else if (!data.find(_type)) 
        return 0;
    else if (!data.find(_titre)) 
        return 0;
    else if (!data.find(retourneType(_type_support))) 
        return 0;
    else if (!data.find(_nom)) 
        return 0;
    else if (!data.find(to_string(_taille_Mo))) 
        return 0;
    else if (!data.find(to_string(_idElement))) 
        return 0;        
    else if (!data.find(_chemin_URL)) 
        return 0;    
    else 
        return 1;
}

string RessourceNumerique::retourneType(enum Type _type){
    if (_type == Type::PDF)
        return "PDF";
    else if (_type == Type::DOC)
        return "Doc";
    else if (_type == Type::PPT)
        return "PPT";
    else    
        return "Autres";
}
