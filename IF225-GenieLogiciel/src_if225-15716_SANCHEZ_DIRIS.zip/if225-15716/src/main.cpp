#include <iostream>
#include "Mediatheque.hpp"

using namespace std;

int main(int argc, char *argv[]){
        Mediatheque maMediatheque;

        maMediatheque.saisieUtilisateur();
    return EXIT_SUCCESS;
}