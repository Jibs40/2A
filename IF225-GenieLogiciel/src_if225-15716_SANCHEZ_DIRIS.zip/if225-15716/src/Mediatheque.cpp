#include "Mediatheque.hpp"

#include <ctime>
#include <string>
#include <iostream>
#include <string.h>


using namespace std;
std::map<int ,Media*> listemedia;

Mediatheque::Mediatheque(void){
}

void Mediatheque::saisieUtilisateur(void){
    time_t tmm = time(0);
    char* dt = ctime(&tmm);

    string buffer;
    string chaine;

    cout << "Data et heure de la connexion : " <<dt<<endl;
    cout<<"_____________________________________________________________________________________________________________________________________________________" << endl
    <<endl
    <<"                                             Bienvenue dans le système de gestion de la Mediatheque" << endl
    <<"                                                        Veuillez entrer votre commande : " << endl
    <<"_____________________________________________________________________________________________________________________________________________________" << endl<<endl

    <<"ADD <type>\t\t\t: Ajouter une ressource (Type peut être : LIVRE, REVUE, VHS, CD, DVD OU RESSOURCE NUMERIQUE)" << endl
    <<"LIST\t\t\t\t: Visualiser l'ensemble des ressources" << endl
    <<"LOAD <filename>\t\t\t: Charger un contenu depuis un fichier externe (voir format dans README)" << endl
    <<"SAVE <filename>\t\t\t: Sauvegarder le contenu de la médiathèque dans un fichierCharger un contenu depuis un fichier externe (voir format dans README)" << endl
    <<"SEARCH <chaine>\t\t\t: Chercher une chaine de caractère dans l'ensemble des ressources" << endl
    <<"SHOW <id>\t\t\t: Afficher les informations détaillées d'une ressource" << endl
    <<"DELETE <id>\t\t\t: Supprimer une ressource particulière" << endl
    <<"RESET\t\t\t\t: Supprimer toutes les ressources" << endl
    <<"CLEAR\t\t\t\t: Effacer ce qui est écrit sur le terminal" << endl
    <<"BYE\t\t\t\t: Quitter" <<endl<<endl;

    while(1){
        getline(cin,chaine);

        if (!chaine.find("BYE")){
            cout <<"A Bientôt!"<<endl;
            break;
        }

        else if (!chaine.find("ADD")){
            AjoutDonnees::ajoutDonnees(chaine);
        }  

        else if (!chaine.find("LOAD")){
            Mediatheque maMediatheque;
            int pos = chaine.find(" "); 
            int taille = chaine.size();
            AjoutDonnees::chargeFichier(chaine.substr(pos+1, taille-(pos+1)));
        }

        else if (!chaine.find("SAVE")){
            int pos = chaine.find(" "); 
            int taille = chaine.size();
            sauvegardeDonnees(chaine.substr(pos+1, taille-(pos+1)));
        }

        else if (!chaine.find("SEARCH")){
            int pos = chaine.find(" "); 
            int taille = chaine.size();
            rechercheDonnees(chaine.substr(pos+1, taille-(pos+1)));
        }

        else if (!chaine.find("CLEAR")){
            cout << "\x1B[2J\x1B[H";        
        }

        else if(!chaine.find("LIST")){
            afficheInfos();
        }

        else if(!chaine.find("SHOW")){
            int taille = chaine.size();
            int pos = chaine.find(" "); 

            string buffer = chaine.substr(pos+1, taille-(pos+1));
            afficheInfos(stoi(buffer));
        }

        else if(!chaine.find("DELETE")){
            int taille = chaine.size();
            int pos = chaine.find(" "); 

            string buffer = chaine.substr(pos+1, taille-(pos+1));
            supprimeRessource(stoi(buffer));
        }

        else if(!chaine.find("RESET")){
            cout << "!!! CETTE COMMANDE VA SUPPRIMER TOUTES LES RESSOURCES DE LA MEDIATHEQUE !!!"<<endl;
            cout << "Etes-vous sûr (oui/non)" <<endl;
            getline(cin,buffer);
                if(!buffer.find("oui")){
                    reset();
                }
        }
        else    
            cout << "Je n'ai pas compris votre demande, attention les commandes doivent êtres écrites en MAJUSCULE"<<endl;
}
}

bool Mediatheque::sauvegardeDonnees(string CheminFichier){
    ofstream outfile;
    outfile.open(CheminFichier);
    
    if (outfile.fail()){
        cout<<"PROBLEME OUVERTURE FICHIER"<<endl;
        return 1;
    } 

    try
    {
        for(int i=0; i<listemedia.size(); i++){
            listemedia.at(i)->sauvegarde(outfile);            
        }    
    }
    catch(const std::out_of_range)
    {
    }

    cout << "Données sauvegardées dans le fichier :" + CheminFichier << endl;
    return 0;
}

void Mediatheque::stockeElement(Media *media, int nbElements){
        listemedia.insert({nbElements,media});
}

void Mediatheque::afficheInfos(void){ 
    map<int,Media*>::iterator it;

    if (listemedia.size() == 0)
        cout << "Pas de Medias en stock" <<endl;
    else{
    cout<<"___________________________________________________________________________MEDIAS STOCKES :___________________________________________________________________________" << endl<<endl;
    try
    {           
    for(it=listemedia.begin(); it!=listemedia.end(); it++){
            it->second->afficheInfo();        
        }
    }
        catch(const std::out_of_range)
        {
        }    
    }
}

void Mediatheque::afficheInfos(int id){
auto item = listemedia.find(id);
    if (item == listemedia.end())
        cout<<"Fichier non trouvé!"<< endl;
    else
        listemedia.at(id)->afficheInfo(); 
}


void Mediatheque::reset(){
    listemedia.clear();
    cout << "Reset effectué" <<endl;
}

void Mediatheque::supprimeRessource(int id){
    auto item = listemedia.find(id);

    if (item == listemedia.end())
	cout << "clé invalide" <<endl;
    else{
        listemedia.erase(id);
        cout << "Media Supprimé" << endl;
    }
}

bool Mediatheque::rechercheDonnees(std::string data){
    map<int,Media*>::iterator it;
    try{
        for(it=listemedia.begin(); it!=listemedia.end(); it++){
            if(it->second->rechercheChaine(data)==0)
                it->second->afficheInfo();
        }
    }
    catch (std::out_of_range)
        {}
return 0;
}

